const Importance = Object.freeze({
    IMPORTANT: "Important",
    NOT_IMPORTANT: "Not Important",
});

export default Importance