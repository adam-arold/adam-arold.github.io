const Urgency = Object.freeze({
    URGENT: "Urgent",
    NOT_URGENT: "Not Urgent",
});

export default Urgency