import React from "react";
import { Link } from "@reach/router";

const Nav = () => {
    return (
        <h1>
            <Link to="/">Eisenhower</Link>
        </h1>
    );
}
export default Nav;